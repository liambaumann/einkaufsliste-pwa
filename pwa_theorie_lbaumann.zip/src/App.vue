<template>
  <div id="app" class="text-center">
    <nav class="m-6">
      <router-link to="/">Meine Liste</router-link> |
      <router-link to="/about">About</router-link>
    </nav>
    <router-view />
  </div>
</template>
